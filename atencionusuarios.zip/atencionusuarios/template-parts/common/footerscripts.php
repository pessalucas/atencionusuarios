
<!-- Vendor -->
<script src="<?php echo get_stylesheet_directory_uri(); ?>/assets/vendor/jquery/jquery.min.js"></script>
<script src="<?php echo get_stylesheet_directory_uri(); ?>/assets/vendor/jquery.appear/jquery.appear.min.js"></script>
<script src="<?php echo get_stylesheet_directory_uri(); ?>/assets/vendor/jquery.easing/jquery.easing.min.js"></script>
<script src="<?php echo get_stylesheet_directory_uri(); ?>/assets/vendor/jquery.cookie/jquery.cookie.min.js"></script>
<script src="<?php echo get_stylesheet_directory_uri(); ?>/assets/vendor/popper/umd/popper.min.js"></script>
<script src="<?php echo get_stylesheet_directory_uri(); ?>/assets/vendor/bootstrap/js/bootstrap.min.js"></script>
<script src="<?php echo get_stylesheet_directory_uri(); ?>/assets/vendor/common/common.min.js"></script>
<script src="<?php echo get_stylesheet_directory_uri(); ?>/assets/vendor/jquery.validation/jquery.validate.min.js"></script>
<script src="<?php echo get_stylesheet_directory_uri(); ?>/assets/vendor/jquery.easy-pie-chart/jquery.easypiechart.min.js"></script>
<script src="<?php echo get_stylesheet_directory_uri(); ?>/assets/vendor/jquery.gmap/jquery.gmap.min.js"></script>
<script src="<?php echo get_stylesheet_directory_uri(); ?>/assets/vendor/jquery.lazyload/jquery.lazyload.min.js"></script>
<script src="<?php echo get_stylesheet_directory_uri(); ?>/assets/vendor/isotope/jquery.isotope.min.js"></script>
<script src="<?php echo get_stylesheet_directory_uri(); ?>/assets/vendor/owl.carousel/owl.carousel.min.js"></script>
<script src="<?php echo get_stylesheet_directory_uri(); ?>/assets/vendor/magnific-popup/jquery.magnific-popup.min.js"></script>
<script src="<?php echo get_stylesheet_directory_uri(); ?>/assets/vendor/vide/jquery.vide.min.js"></script>
<script src="<?php echo get_stylesheet_directory_uri(); ?>/assets/vendor/vivus/vivus.min.js"></script>
		
<!-- Theme Base, Components and Settings -->
<script src="<?php echo get_stylesheet_directory_uri(); ?>/assets/js/theme.js"></script>
		
<!-- Current Page Vendor and Views -->
<script src="<?php echo get_stylesheet_directory_uri(); ?>/assets/vendor/rs-plugin/js/jquery.themepunch.tools.min.js"></script>
<script src="<?php echo get_stylesheet_directory_uri(); ?>/assets/vendor/rs-plugin/js/jquery.themepunch.revolution.min.js"></script>



<!-- Demo -->
<script src="<?php echo get_stylesheet_directory_uri(); ?>/assets/js/demos/demo-it-services.js"></script>

<!-- Theme Custom -->
<script src="<?php echo get_stylesheet_directory_uri(); ?>/assets/js/custom.js"></script>
		
<!-- Theme Initialization Files -->
<script src="<?php echo get_stylesheet_directory_uri(); ?>/assets/js/theme.init.js"></script>
        
<?php wp_footer(); ?>


